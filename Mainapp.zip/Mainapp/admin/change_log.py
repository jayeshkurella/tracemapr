"""
Created By : Sanket Lodhe
Created Date : Feb 2025
"""
from django.contrib import admin

from ..models import ChangeLog


admin.site.register(ChangeLog)
