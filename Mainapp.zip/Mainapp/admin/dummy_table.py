"""
Created By : Sanket Lodhe
Created Date : Feb 2025
"""
from ..models import dummy_Table
from django.contrib import admin

admin.site.register(dummy_Table)