"""
Created By : Sanket Lodhe
Created Date : Feb 2025
"""
from Mainapp.Additional_info_Tags.tags_model import educational_tag, occupation_tags
from django.contrib import admin

admin.site.register(educational_tag)
admin.site.register(occupation_tags)