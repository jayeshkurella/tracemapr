"""
Created By : Sanket Lodhe
Created Date : Feb 2025
"""

from django.apps import AppConfig


class MainappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Mainapp'
